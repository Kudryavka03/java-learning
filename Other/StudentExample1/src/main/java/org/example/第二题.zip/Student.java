package org.example;

public class Student {
    String name;
    int age;
    double score;
    String classNum;

    public Student(String name, int age, double score, String classNum) {
        this.age = age;
        this.name = name;
        this.score = score;
        this.classNum = classNum;
    }

}
